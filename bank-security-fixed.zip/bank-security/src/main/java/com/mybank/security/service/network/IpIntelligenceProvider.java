package com.mybank.security.service.network;

public interface IpIntelligenceProvider {
    IpIntelligenceResult check(String ipAddress);
}
