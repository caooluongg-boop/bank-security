package com.mybank.security.service.network;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class IpQualityScoreProvider implements IpIntelligenceProvider {

    @Value("${app.network.ipqs-api-key:}")
    private String apiKey;

    @Value("${app.network.ipqs-enabled:false}")
    private boolean enabled;

    @Value("${app.network.ipqs-connect-timeout-ms:800}")
    private int connectTimeoutMs;

    @Value("${app.network.ipqs-read-timeout-ms:1200}")
    private int readTimeoutMs;

    @Value("${app.network.ipqs-fail-open:true}")
    private boolean failOpen;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private RestTemplate buildRestTemplate() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(connectTimeoutMs);
        factory.setReadTimeout(readTimeoutMs);
        return new RestTemplate(factory);
    }

    @Override
    public IpIntelligenceResult check(String ipAddress) {
        if (!enabled || apiKey == null || apiKey.isBlank()) {
            return new IpIntelligenceResult(false, false, false, false, "PROVIDER_DISABLED");
        }

        try {
            String url = "https://ipqualityscore.com/api/json/ip/" + apiKey + "/" + ipAddress
                    + "?strictness=1&allow_public_access_points=true";

            String response = buildRestTemplate().getForObject(url, String.class);
            JsonNode node = objectMapper.readTree(response);

            boolean vpn = node.path("vpn").asBoolean(false);
            boolean proxy = node.path("proxy").asBoolean(false);
            boolean tor = node.path("tor").asBoolean(false);
            boolean datacenter = node.path("connection_type").asText("").equalsIgnoreCase("Data Center");

            return new IpIntelligenceResult(vpn, proxy, tor, datacenter, "IPQS_CHECK");
        } catch (RestClientException e) {
            return fallbackResult("IPQS_TIMEOUT_OR_ERROR");
        } catch (Exception e) {
            return fallbackResult("IPQS_PARSE_ERROR");
        }
    }

    private IpIntelligenceResult fallbackResult(String reason) {
        if (failOpen) {
            return new IpIntelligenceResult(false, false, false, false, reason + ":FAIL_OPEN");
        }
        return new IpIntelligenceResult(false, false, false, true, reason + ":FAIL_CLOSED");
    }
}
