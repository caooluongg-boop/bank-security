package com.mybank.security.service;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.BucketConfiguration;
import io.github.bucket4j.Refill;
import io.github.bucket4j.distributed.proxy.ProxyManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.function.Supplier;

@Component
public class LoginRateLimiter {

    @Autowired
    private ProxyManager<byte[]> bucketProxyManager;

    private final Supplier<BucketConfiguration> configuration = () -> BucketConfiguration.builder()
            .addLimit(Bandwidth.classic(5, Refill.intervally(5, Duration.ofMinutes(15))))
            .build();

    public boolean tryConsume(String usernameOrIp) {
        byte[] key = ("rl:login:" + usernameOrIp).getBytes(StandardCharsets.UTF_8);
        return bucketProxyManager.builder().build(key, configuration).tryConsume(1);
    }
}
