package com.mybank.security.service;

import com.mybank.security.model.User;
import com.mybank.security.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private EncryptionService encryptionService;

    @Autowired
    private TotpService totpService;

    public static class RegistrationResult {
        public final User user;
        public final String plainTotpSecret;

        public RegistrationResult(User user, String plainTotpSecret) {
            this.user = user;
            this.plainTotpSecret = plainTotpSecret;
        }
    }

    public RegistrationResult registerUser(String username, String rawPassword) {
        if (rawPassword == null || rawPassword.length() < 12) {
            throw new IllegalArgumentException("Mật khẩu tối thiểu 12 ký tự");
        }

        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(passwordEncoder.encode(rawPassword));

        String totpSecret = totpService.generateSecret();
        user.setTotpSecretEncrypted(encryptionService.encrypt(totpSecret));

        User saved = userRepository.save(user);
        return new RegistrationResult(saved, totpSecret);
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }

    public boolean checkPassword(String rawPassword, String storedHash) {
        return passwordEncoder.matches(rawPassword, storedHash);
    }

    public String getDecryptedTotpSecret(User user) {
        return encryptionService.decrypt(user.getTotpSecretEncrypted());
    }

    private static final String DUMMY_HASH =
            "$argon2id$v=19$m=65536,t=3,p=1$c29tZXJhbmRvbXNhbHQ$KZgxfj8U9L6f3wq2vB1nH8yP4rQ0mZtV5oS6cW2xE9I";

    public String getDummyHash() {
        return DUMMY_HASH;
    }
}
