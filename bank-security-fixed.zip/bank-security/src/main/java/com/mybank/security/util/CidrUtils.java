package com.mybank.security.util;

import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class CidrUtils {

    public static boolean isInRange(String ip, String cidr) {
        try {
            String[] parts = cidr.split("/");
            InetAddress targetAddress = InetAddress.getByName(ip);
            InetAddress rangeAddress = InetAddress.getByName(parts[0]);
            int prefixLength = parts.length > 1 ? Integer.parseInt(parts[1]) : 32;

            byte[] targetBytes = targetAddress.getAddress();
            byte[] rangeBytes = rangeAddress.getAddress();

            if (targetBytes.length != rangeBytes.length) {
                return false;
            }

            BigInteger targetBig = new BigInteger(1, targetBytes);
            BigInteger rangeBig = new BigInteger(1, rangeBytes);

            int addressBits = targetBytes.length * 8;
            BigInteger mask = BigInteger.ZERO.setBit(addressBits).subtract(BigInteger.ONE)
                    .shiftRight(addressBits - prefixLength)
                    .shiftLeft(addressBits - prefixLength);

            return targetBig.and(mask).equals(rangeBig.and(mask));
        } catch (UnknownHostException | NumberFormatException | ArithmeticException e) {
            return false;
        }
    }
}
