package com.mybank.security.config;

import io.github.bucket4j.distributed.ExpirationAfterWriteStrategy;
import io.github.bucket4j.distributed.proxy.ProxyManager;
import io.github.bucket4j.redis.lettuce.cas.LettuceBasedProxyManager;
import io.lettuce.core.RedisURI;
import io.lettuce.core.cluster.ClusterClientOptions;
import io.lettuce.core.cluster.ClusterTopologyRefreshOptions;
import io.lettuce.core.cluster.RedisClusterClient;
import io.lettuce.core.cluster.api.StatefulRedisClusterConnection;
import io.lettuce.core.codec.ByteArrayCodec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

@Configuration
public class RedisRateLimitConfig {

    @Value("${app.redis.nodes}")
    private String redisNodes;

    @Bean(destroyMethod = "shutdown")
    public RedisClusterClient redisClusterClient() {
        List<RedisURI> nodes = Arrays.stream(redisNodes.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(hostPort -> {
                    String[] parts = hostPort.split(":");
                    return RedisURI.create(parts[0], Integer.parseInt(parts[1]));
                })
                .toList();

        RedisClusterClient client = RedisClusterClient.create(nodes);

        ClusterTopologyRefreshOptions topologyRefreshOptions = ClusterTopologyRefreshOptions.builder()
                .enablePeriodicRefresh(Duration.ofSeconds(30))
                .enableAllAdaptiveRefreshTriggers()
                .build();

        client.setOptions(ClusterClientOptions.builder()
                .topologyRefreshOptions(topologyRefreshOptions)
                .build());

        return client;
    }

    @Bean(destroyMethod = "close")
    public StatefulRedisClusterConnection<byte[], byte[]> redisClusterConnection(RedisClusterClient redisClusterClient) {
        return redisClusterClient.connect(ByteArrayCodec.INSTANCE);
    }

    @Bean
    public ProxyManager<byte[]> bucketProxyManager(StatefulRedisClusterConnection<byte[], byte[]> connection) {
        return LettuceBasedProxyManager.builderFor(connection)
                .withExpirationStrategy(
                        ExpirationAfterWriteStrategy.basedOnTimeForRefillingBucketUpToMax(Duration.ofMinutes(20)))
                .build();
    }
}
