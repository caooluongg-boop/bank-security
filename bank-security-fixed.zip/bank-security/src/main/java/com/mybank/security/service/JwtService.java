package com.mybank.security.service;

import com.mybank.security.model.RefreshTokenEntity;
import com.mybank.security.model.User;
import com.mybank.security.repository.RefreshTokenRepository;
import com.mybank.security.repository.UserRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.SecretKey;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Base64;
import java.util.Date;
import java.util.Optional;

@Service
public class JwtService {

    @Value("${app.jwt.secret}")
    private String base64Secret;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RefreshTokenRepository refreshTokenRepository;

    private static final long TEMP_MFA_TTL_MS = 5 * 60 * 1000;
    private static final long ACCESS_TTL_MS = 15 * 60 * 1000;
    private static final long REFRESH_TTL_MS = 7L * 24 * 60 * 60 * 1000;

    private SecretKey getKey() {
        byte[] keyBytes = Base64.getDecoder().decode(base64Secret);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    private String buildToken(Long userId, String type, long ttlMs) {
        Date now = new Date();
        Date expiry = new Date(now.getTime() + ttlMs);

        return Jwts.builder()
                .subject(String.valueOf(userId))
                .claim("type", type)
                .issuedAt(now)
                .expiration(expiry)
                .signWith(getKey())
                .compact();
    }

    public String issueTempMfaToken(User user) {
        return buildToken(user.getId(), "MFA_PENDING", TEMP_MFA_TTL_MS);
    }

    public String generateAccessToken(User user) {
        return buildToken(user.getId(), "ACCESS", ACCESS_TTL_MS);
    }

    private String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(value.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    @Transactional
    public String generateRefreshToken(User user) {
        String token = buildToken(user.getId(), "REFRESH", REFRESH_TTL_MS);

        RefreshTokenEntity entity = new RefreshTokenEntity();
        entity.setUserId(user.getId());
        entity.setTokenHash(sha256(token));
        entity.setExpiresAt(Instant.now().plusMillis(REFRESH_TTL_MS));
        entity.setRevoked(false);
        refreshTokenRepository.save(entity);

        return token;
    }

    @Transactional
    public User rotateRefreshToken(String presentedToken) {
        Claims claims;
        try {
            claims = parseClaims(presentedToken);
        } catch (Exception e) {
            return null;
        }
        if (!"REFRESH".equals(claims.get("type", String.class))) {
            return null;
        }

        String tokenHash = sha256(presentedToken);
        Optional<RefreshTokenEntity> stored = refreshTokenRepository.findByTokenHashForUpdate(tokenHash);

        if (stored.isEmpty()) {
            return null;
        }

        RefreshTokenEntity entity = stored.get();

        if (entity.isRevoked() || entity.getExpiresAt().isBefore(Instant.now())) {
            refreshTokenRepository.deleteByUserId(entity.getUserId());
            return null;
        }

        entity.setRevoked(true);
        refreshTokenRepository.saveAndFlush(entity);

        Long userId = Long.valueOf(claims.getSubject());
        return userRepository.findById(userId).orElse(null);
    }

    @Transactional
    public void revokeAllRefreshTokens(Long userId) {
        refreshTokenRepository.deleteByUserId(userId);
    }

    @Transactional
    public boolean logout(String presentedToken) {
        Claims claims;
        try {
            claims = Jwts.parser()
                    .verifyWith(getKey())
                    .clockSkewSeconds(Long.MAX_VALUE / 1000)
                    .build()
                    .parseSignedClaims(presentedToken)
                    .getPayload();
        } catch (Exception e) {
            return false;
        }

        if (!"REFRESH".equals(claims.get("type", String.class))) {
            return false;
        }

        Long userId = Long.valueOf(claims.getSubject());
        refreshTokenRepository.deleteByUserId(userId);
        return true;
    }

    private Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith(getKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public User validateTempToken(String token) {
        try {
            Claims claims = parseClaims(token);
            if (!"MFA_PENDING".equals(claims.get("type", String.class))) {
                return null;
            }
            Long userId = Long.valueOf(claims.getSubject());
            return userRepository.findById(userId).orElse(null);
        } catch (Exception e) {
            return null;
        }
    }

    public User validateAccessToken(String token) {
        try {
            Claims claims = parseClaims(token);
            if (!"ACCESS".equals(claims.get("type", String.class))) {
                return null;
            }
            Long userId = Long.valueOf(claims.getSubject());
            return userRepository.findById(userId).orElse(null);
        } catch (Exception e) {
            return null;
        }
    }

}
