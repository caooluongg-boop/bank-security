package com.mybank.security.service.network;

import com.mybank.security.util.CidrUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CidrBlocklistProvider implements IpIntelligenceProvider {

    @Value("${app.network.blocked-cidrs:}")
    private String blockedCidrsRaw;

    private List<String> parsedCidrs() {
        List<String> result = new ArrayList<>();
        if (blockedCidrsRaw != null && !blockedCidrsRaw.isBlank()) {
            for (String cidr : blockedCidrsRaw.split(",")) {
                String trimmed = cidr.trim();
                if (!trimmed.isEmpty()) {
                    result.add(trimmed);
                }
            }
        }
        return result;
    }

    @Override
    public IpIntelligenceResult check(String ipAddress) {
        for (String cidr : parsedCidrs()) {
            if (CidrUtils.isInRange(ipAddress, cidr)) {
                return new IpIntelligenceResult(false, false, false, true, "CIDR_BLOCKLIST:" + cidr);
            }
        }
        return new IpIntelligenceResult(false, false, false, false, "CIDR_CLEAN");
    }
}
