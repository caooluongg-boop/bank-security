package com.mybank.security.dto;

public class MfaChallengeResponse {

    private String tempToken;
    private String nextStep;

    public MfaChallengeResponse(String tempToken, String nextStep) {
        this.tempToken = tempToken;
        this.nextStep = nextStep;
    }

    public String getTempToken() {
        return tempToken;
    }

    public void setTempToken(String tempToken) {
        this.tempToken = tempToken;
    }

    public String getNextStep() {
        return nextStep;
    }

    public void setNextStep(String nextStep) {
        this.nextStep = nextStep;
    }
}
