package com.mybank.security.util;

import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public class ClientIpResolver {

    public static String resolve(HttpServletRequest request, List<String> trustedProxyCidrs) {
        String remoteAddr = request.getRemoteAddr();

        if (trustedProxyCidrs == null || trustedProxyCidrs.isEmpty()) {
            return remoteAddr;
        }

        boolean isFromTrustedProxy = trustedProxyCidrs.stream()
                .anyMatch(cidr -> CidrUtils.isInRange(remoteAddr, cidr));

        if (!isFromTrustedProxy) {
            return remoteAddr;
        }

        String forwardedFor = request.getHeader("X-Forwarded-For");
        if (forwardedFor != null && !forwardedFor.isBlank()) {
            return forwardedFor.split(",")[0].trim();
        }

        String realIp = request.getHeader("X-Real-IP");
        if (realIp != null && !realIp.isBlank()) {
            return realIp.trim();
        }

        return remoteAddr;
    }
}
