package com.mybank.security.filter;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.BucketConfiguration;
import io.github.bucket4j.Refill;
import io.github.bucket4j.distributed.proxy.ProxyManager;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.function.Supplier;

@Component
public class IpRateLimitFilter extends OncePerRequestFilter {

    @Autowired
    private ProxyManager<byte[]> bucketProxyManager;

    private final Supplier<BucketConfiguration> configuration = () -> BucketConfiguration.builder()
            .addLimit(Bandwidth.classic(30, Refill.intervally(30, Duration.ofMinutes(1))))
            .build();

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                     HttpServletResponse response,
                                     FilterChain filterChain) throws ServletException, IOException {

        if (!isProtectedPath(request.getRequestURI())) {
            filterChain.doFilter(request, response);
            return;
        }

        String ip = request.getRemoteAddr();
        byte[] key = ("rl:ip:" + ip).getBytes(StandardCharsets.UTF_8);

        if (!bucketProxyManager.builder().build(key, configuration).tryConsume(1)) {
            response.setStatus(HttpServletResponse.SC_TOO_MANY_REQUESTS);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"error\":\"Quá nhiều request. Thử lại sau.\"}");
            return;
        }

        filterChain.doFilter(request, response);
    }

    private boolean isProtectedPath(String uri) {
        return uri.startsWith("/auth/login")
                || uri.startsWith("/auth/verify-otp")
                || uri.startsWith("/auth/register")
                || uri.startsWith("/auth/refresh")
                || uri.startsWith("/transfer");
    }
}
