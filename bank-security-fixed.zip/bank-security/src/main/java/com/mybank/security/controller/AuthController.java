package com.mybank.security.controller;

import com.mybank.security.dto.*;
import com.mybank.security.model.User;
import com.mybank.security.service.JwtService;
import com.mybank.security.service.LoginRateLimiter;
import com.mybank.security.service.TotpService;
import com.mybank.security.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired private LoginRateLimiter rateLimiter;
    @Autowired private UserService userService;
    @Autowired private TotpService totpService;
    @Autowired private JwtService jwtService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (userService.findByUsername(req.getUsername()) != null) {
            return ResponseEntity.status(400).body("Không thể tạo tài khoản với thông tin đã cung cấp");
        }

        UserService.RegistrationResult result = userService.registerUser(req.getUsername(), req.getPassword());
        String qrUri = totpService.getQrCodeUri(result.plainTotpSecret, req.getUsername());

        return ResponseEntity.ok(new RegisterResponse(result.user.getId(), result.user.getUsername(), qrUri));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req, HttpServletRequest httpReq) {
        String clientKey = req.getUsername() + "|" + httpReq.getRemoteAddr();

        if (!rateLimiter.tryConsume(clientKey)) {
            return ResponseEntity.status(429).body("Quá nhiều lần thử. Thử lại sau.");
        }

        User user = userService.findByUsername(req.getUsername());
        boolean passwordOk;
        if (user != null) {
            passwordOk = userService.checkPassword(req.getPassword(), user.getPasswordHash());
        } else {
            userService.checkPassword(req.getPassword(), userService.getDummyHash());
            passwordOk = false;
        }

        if (!passwordOk) {
            return ResponseEntity.status(401).body("Sai tài khoản hoặc mật khẩu");
        }

        String tempToken = jwtService.issueTempMfaToken(user);
        return ResponseEntity.ok(new MfaChallengeResponse(tempToken, "ENTER_OTP"));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody OtpRequest req) {
        User user = jwtService.validateTempToken(req.getTempToken());
        if (user == null) {
            return ResponseEntity.status(401).body("Phiên hết hạn");
        }

        String secret = userService.getDecryptedTotpSecret(user);
        if (!totpService.verifyCode(secret, req.getCode())) {
            return ResponseEntity.status(401).body("Mã OTP không đúng");
        }

        String accessToken = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);
        return ResponseEntity.ok(new AuthResponse(accessToken, refreshToken));
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@RequestBody RefreshRequest req) {
        User user = jwtService.rotateRefreshToken(req.getRefreshToken());
        if (user == null) {
            return ResponseEntity.status(401).body("Refresh token không hợp lệ hoặc đã bị thu hồi");
        }

        String accessToken = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);
        return ResponseEntity.ok(new AuthResponse(accessToken, refreshToken));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestBody RefreshRequest req) {
        boolean deleted = jwtService.logout(req.getRefreshToken());
        if (!deleted) {
            return ResponseEntity.status(400).body("Token không hợp lệ");
        }
        return ResponseEntity.ok("Đã đăng xuất, mọi phiên đăng nhập đã được thu hồi");
    }
}
