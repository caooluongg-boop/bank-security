package com.mybank.security.service.network;

public class IpIntelligenceResult {

    private final boolean vpn;
    private final boolean proxy;
    private final boolean tor;
    private final boolean datacenter;
    private final String reason;

    public IpIntelligenceResult(boolean vpn, boolean proxy, boolean tor, boolean datacenter, String reason) {
        this.vpn = vpn;
        this.proxy = proxy;
        this.tor = tor;
        this.datacenter = datacenter;
        this.reason = reason;
    }

    public boolean isSuspicious() {
        return vpn || proxy || tor || datacenter;
    }

    public boolean isVpn() {
        return vpn;
    }

    public boolean isProxy() {
        return proxy;
    }

    public boolean isTor() {
        return tor;
    }

    public boolean isDatacenter() {
        return datacenter;
    }

    public String getReason() {
        return reason;
    }
}
