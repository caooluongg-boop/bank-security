package com.mybank.security.service.network;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NetworkGuardService {

    @Autowired
    private CidrBlocklistProvider cidrBlocklistProvider;

    @Autowired
    private IpQualityScoreProvider ipQualityScoreProvider;

    public IpIntelligenceResult evaluate(String clientIp) {
        IpIntelligenceResult cidrResult = cidrBlocklistProvider.check(clientIp);
        if (cidrResult.isSuspicious()) {
            return cidrResult;
        }

        return ipQualityScoreProvider.check(clientIp);
    }
}
