package com.mybank.security.dto;

public class RegisterResponse {

    private Long userId;
    private String username;
    private String totpQrUri;

    public RegisterResponse(Long userId, String username, String totpQrUri) {
        this.userId = userId;
        this.username = username;
        this.totpQrUri = totpQrUri;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTotpQrUri() {
        return totpQrUri;
    }

    public void setTotpQrUri(String totpQrUri) {
        this.totpQrUri = totpQrUri;
    }
}
