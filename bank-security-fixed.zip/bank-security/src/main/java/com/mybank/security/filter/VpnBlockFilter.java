package com.mybank.security.filter;

import com.mybank.security.service.network.IpIntelligenceResult;
import com.mybank.security.service.network.NetworkGuardService;
import com.mybank.security.util.ClientIpResolver;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class VpnBlockFilter extends OncePerRequestFilter {

    @Autowired
    private NetworkGuardService networkGuardService;

    @Value("${app.network.block-enabled:false}")
    private boolean blockEnabled;

    @Value("${app.network.trusted-proxies:}")
    private String trustedProxiesRaw;

    private List<String> trustedProxies() {
        List<String> result = new ArrayList<>();
        if (trustedProxiesRaw != null && !trustedProxiesRaw.isBlank()) {
            for (String cidr : trustedProxiesRaw.split(",")) {
                String trimmed = cidr.trim();
                if (!trimmed.isEmpty()) {
                    result.add(trimmed);
                }
            }
        }
        return result;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                     HttpServletResponse response,
                                     FilterChain filterChain) throws ServletException, IOException {

        if (!blockEnabled || !isProtectedPath(request.getRequestURI())) {
            filterChain.doFilter(request, response);
            return;
        }

        String clientIp = ClientIpResolver.resolve(request, trustedProxies());
        IpIntelligenceResult result = networkGuardService.evaluate(clientIp);

        if (result.isSuspicious()) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(
                    "{\"error\":\"Kết nối của bạn bị chặn vì lý do bảo mật. Vui lòng tắt VPN/Proxy và thử lại.\"}"
            );
            return;
        }

        filterChain.doFilter(request, response);
    }

    private boolean isProtectedPath(String uri) {
        return uri.startsWith("/auth/login")
                || uri.startsWith("/auth/verify-otp")
                || uri.startsWith("/auth/register")
                || uri.startsWith("/auth/refresh")
                || uri.startsWith("/transfer");
    }
}
