package com.mybank.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class BankSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankSecurityApplication.class, args);
    }
}
